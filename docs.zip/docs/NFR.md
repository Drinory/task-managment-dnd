# NFR — Mini Kanban (DnD Multiple Containers)

**Version:** 1.0 • **Date:** 2025-10-05 • **Owner:** You  
**Implementation reference:** `/docs/ref/dnd/MultipleContainers.demo.tsx`  
**Specs:** `/docs/specs/spec-m1-*.md`

## 1. Performance
- **Target (seeded dev data):** p95 time-to-first-row (TFR) ≤ **300 ms** for columns view; p95 DnD commit → UI settle ≤ **150 ms**.
- **Drag smoothness:** 60 fps perceived while dragging on a 60 Hz display (Chrome desktop).
- **Client memory:** < **150 MB** app heap on seed dataset; no sustained growth during 200 consecutive drags (leak guard).

## 2. Availability & Reliability
- **Scope:** local single-user demo (no HA).  
- **Error handling:** On tRPC mutation failure, **rollback** optimistic state and show toast with code (`BAD_REQUEST|NOT_FOUND|CONFLICT|INTERNAL_SERVER_ERROR`).  
- **Idempotency:** Same “move” repeated should converge (server treats “no index change” as success).

## 3. Security & Privacy
- No auth in MVP (local demo). Do not log card titles in console at “error” level.  
- Sanitize all user-facing text; no HTML injection in titles/descriptions.  
- CORS restricted to same-origin; cookies not used.

## 4. Accessibility (A11y)
- Keyboard DnD works (Arrow keys to move drag overlay; Enter/Space to pick/drop per dnd-kit defaults/handlers).  
- Focus rings visible; drag handles have `aria-label`.  
- Color is not the sole signal (hover ring + opacity used).

## 5. Internationalization (i18n)
- English-only copy; strings centralized for future i18n.

## 6. Observability
- Minimal console diagnostics behind `NODE_ENV !== 'production'`.  
- Add a simple timing log in the DX smoke script (start/end) and count of moves.  
- No PII telemetry; local only.

## 7. Testability
- Deterministic seeding.  
- **Smoke:** programmatic moves validate strictly increasing `order` for both columns and tasks.  
- Component tests: collision helper and optimistic reducers are unit-testable.

## 8. Portability
- Node 20 LTS; Next.js App Router; SQLite for local storage.  
- No native deps beyond Prisma engine binaries.

## 9. Maintainability
- TypeScript strict (no `any` in app code).  
- tRPC routers colocate Zod validation.  
- Ordering math is shared (tasks & columns) and documented in `/docs/specs/spec-m1-task-move-ordering.md`.
