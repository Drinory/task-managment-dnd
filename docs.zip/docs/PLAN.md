# PLAN — Mini Kanban (M1: DnD Multiple Containers)

**Timestamp:** 2025-10-05 (Europe/Belgrade)  
**Links:**  
- PRD → `/docs/PRD.md`  
- SAD → `/docs/SAD.md`  
- NFR → `/docs/NFR.md`  
- Specs → `/docs/specs/`  
- Reference code → `/docs/ref/dnd/MultipleContainers.demo.tsx`

## Milestone DAG
```
M1.DnD+Ordering
 ├─ M1.1 ColumnsRouter.move (server)
 ├─ M1.2 React Query optimistic adapters (tasks.move, columns.move, tasks.remove)
 ├─ M1.3 UI wiring (sensors, collision, measuring, overlay, placeholder, trash)
 ├─ M1.4 Seed & Smoke (tasks+columns moves + invariants)
 └─ M1.5 QA pass (keyboard DnD, a11y, error toasts)
```
**Dependencies:** Prisma schema finalized (`Column.order`, `Task.order`), basic list UIs present.

## Exit Criteria (mapped to specs)
- **DnD Wiring & Optimistic UI** (`spec-m1-dnd-optimistic-ui.md`):  
  Multi-sensor (Mouse/Touch/Keyboard); container-first collision; Always measuring; horizontal columns + vertical tasks; placeholder; optional trash; optimistic flows for tasks & columns.
- **Routers & CRUD** (`spec-m1-routers-and-crud.md`):  
  `ColumnsRouter.move` implemented with error taxonomy and idempotency.
- **Task/Column Ordering** (`spec-m1-task-move-ordering.md`):  
  Sparse Int order + renorm rules shared; tests outlined.
- **Seed/Reset/DX** (`spec-m1-seed-reset-dx.md`):  
  Smoke runs and validates increasing order after random moves.

## Open Questions (+ chosen defaults)
1. **Trash scope?** Tasks only. **Default:** keep columns deletion explicit and allowed only when empty.  
2. **Activation distance?** 6 px for pointer devices.  
3. **Renorm cadence?** When min gap < 2 or after 50 moves (per scope).  
4. **Placeholder behavior on drop?** Create server column, then move card into it (two-step) or allow only click? **Default:** click-only in MVP; drop shows toast “Create a column first.” (Toggleable later).

## Risks
- Keyboard DnD parity across browsers → mitigated via minimal `coordinateGetter` plus manual testing.  
- Jitter in collision near container edges → mitigated via `lastOverId` fallback.

## Notes
- Keep spec and code in lockstep; update this PLAN when edge-cases are discovered.
