/* 
  MultipleContainers.demo.tsx — Self‑contained reference for dnd‑kit “Multiple Containers”
  -------------------------------------------------------------------------------
  Purpose: A drop‑in, buildable reference to open in Cursor alongside app code.
  Swap local state for React Query + tRPC mutations in production:
   - tasks.move, columns.move, columns.create, tasks.remove
*/

import React, {useCallback, useEffect, useRef, useState} from 'react';
import {createPortal, unstable_batchedUpdates} from 'react-dom';
import {
  CancelDrop,
  closestCenter,
  pointerWithin,
  rectIntersection,
  CollisionDetection,
  DndContext,
  DragOverlay,
  DropAnimation,
  getFirstCollision,
  KeyboardSensor,
  MouseSensor,
  TouchSensor,
  Modifiers,
  useDroppable,
  UniqueIdentifier,
  useSensors,
  useSensor,
  MeasuringStrategy,
  KeyboardCoordinateGetter,
  defaultDropAnimationSideEffects,
} from '@dnd-kit/core';
import {
  AnimateLayoutChanges,
  SortableContext,
  useSortable,
  arrayMove,
  defaultAnimateLayoutChanges,
  verticalListSortingStrategy,
  SortingStrategy,
  horizontalListSortingStrategy,
} from '@dnd-kit/sortable';
import {CSS} from '@dnd-kit/utilities';

/** Keyboard coordinate getter (minimal) */
export const multipleContainersCoordinateGetter: KeyboardCoordinateGetter = (event, {currentCoordinates}) => {
  const step = 25;
  switch (event.code) {
    case 'ArrowDown': return {x: currentCoordinates.x, y: currentCoordinates.y + step};
    case 'ArrowUp':   return {x: currentCoordinates.x, y: currentCoordinates.y - step};
    case 'ArrowLeft': return {x: currentCoordinates.x - step, y: currentCoordinates.y};
    case 'ArrowRight':return {x: currentCoordinates.x + step, y: currentCoordinates.y};
    default: return undefined;
  }
};

/** Tiny UI primitives so the file runs standalone */
function cn(...a: Array<string | false | undefined>) {return a.filter(Boolean).join(' ')}
const Card: React.FC<React.PropsWithChildren<{className?: string}>> = ({className, children}) => (
  <div className={cn('rounded-xl border border-neutral-200 bg-white shadow-sm', className)}>{children}</div>
);

const DemoItem = React.forwardRef<HTMLDivElement, {
  value: UniqueIdentifier; handle?: boolean; listeners?: any; handleProps?: any;
  color?: string; sorting?: boolean; dragging?: boolean;
  transition?: string | undefined; transform?: any;
  style?: React.CSSProperties; wrapperStyle?: React.CSSProperties; fadeIn?: boolean;
}>(function Item(props, ref) {
  const {value, handle, listeners, handleProps, color, sorting, dragging, transition, transform, style, wrapperStyle} = props;
  return (
    <div style={wrapperStyle}>
      <div
        ref={ref}
        className={cn('mb-2 select-none overflow-hidden rounded-lg border bg-white',
          dragging && 'opacity-50', sorting && 'ring-2 ring-blue-400'
        )}
        style={{transition, transform: CSS.Translate.toString(transform),
                boxShadow: '0 1px 2px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06)', ...style}}
      >
        <div className="flex items-center gap-2 p-2">
          {handle ? (
            <span {...listeners} {...handleProps}
              className="inline-flex h-6 w-6 cursor-grab items-center justify-center rounded-md border bg-neutral-50"
              aria-label="drag handle">≡</span>
          ) : null}
          <div className="h-4 w-4 rounded" style={{background: color}} />
          <div className="text-sm font-medium">{String(value)}</div>
        </div>
      </div>
    </div>
  );
});

const DemoContainer = React.forwardRef<HTMLDivElement, React.PropsWithChildren<{
  label?: string; hover?: boolean; placeholder?: boolean; onClick?: () => void;
  unstyled?: boolean; columns?: number; style?: React.CSSProperties; handleProps?: any; scrollable?: boolean;
}>>(function Container({label, children, hover, placeholder, onClick, columns = 1, style, handleProps, scrollable}, ref) {
  if (placeholder) {
    return (
      <button onClick={onClick}
        className="flex h-[420px] w-[280px] items-center justify-center rounded-xl border-2 border-dashed text-sm text-neutral-500 hover:bg-neutral-50">
        + Add column
      </button>
    );
  }
  return (
    <div ref={ref}>
      <Card className={cn('flex h-[420px] w-[280px] flex-col', hover && 'ring-2 ring-blue-400')}>
        <div className="flex items-center justify-between border-b px-3 py-2">
          <div className="text-sm font-semibold text-neutral-700">{label}</div>
          {handleProps ? (<span {...handleProps} className="cursor-grab rounded-md border px-2 py-1 text-xs">Move</span>) : null}
        </div>
        <div className={cn('flex-1 p-3', scrollable && 'overflow-auto')} style={{
          display: 'grid', gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`, gap: 8, ...style,
        }}>{children}</div>
      </Card>
    </div>
  );
});

/** Types & constants */
export type Items = Record<UniqueIdentifier, UniqueIdentifier[]>;
export const TRASH_ID = 'void';
const PLACEHOLDER_ID = 'placeholder';
const empty: UniqueIdentifier[] = [];

const animateLayoutChanges: AnimateLayoutChanges = (args) =>
  defaultAnimateLayoutChanges({...args, wasDragging: true});

/** Column that is itself sortable (container reordering) */
function DroppableContainer({
  children, columns = 1, disabled, id, items, style, scrollable, ...props
}: {
  children?: React.ReactNode; columns?: number; disabled?: boolean;
  id: UniqueIdentifier; items: UniqueIdentifier[]; style?: React.CSSProperties; scrollable?: boolean;
} & React.ComponentProps<typeof DemoContainer>) {
  const {active, attributes, isDragging, listeners, over, setNodeRef, transition, transform} = useSortable({
    id, data: {type: 'container', children: items}, animateLayoutChanges,
  });
  const isOverContainer = over
    ? (id === over.id && active?.data.current?.type !== 'container') || items.includes(over.id)
    : false;

  return (
    <DemoContainer
      ref={disabled ? undefined : setNodeRef}
      style={{...style, transition, transform: CSS.Translate.toString(transform), opacity: isDragging ? 0.5 : undefined}}
      hover={isOverContainer}
      handleProps={{...attributes, ...listeners}}
      columns={columns}
      scrollable={scrollable}
      {...props}
    >{children}</DemoContainer>
  );
}

/** Trash droppable (task delete only) */
function Trash({id}: {id: UniqueIdentifier}) {
  const {setNodeRef, isOver} = useDroppable({id});
  return (
    <div
      ref={setNodeRef}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'fixed', left: '50%', marginLeft: -150, bottom: 20,
        width: 300, height: 60, borderRadius: 8, border: '1px solid',
        borderColor: isOver ? 'red' : '#DDD', background: '#fff'
      }}
    >Drop here to delete</div>
  );
}

/** Sortable item (task card) */
function SortableItem({
  disabled, id, index, handle, renderItem, style, containerId, getIndex, wrapperStyle,
}: {
  containerId: UniqueIdentifier; id: UniqueIdentifier; index: number; handle: boolean; disabled?: boolean;
  style(args: any): React.CSSProperties; getIndex(id: UniqueIdentifier): number;
  renderItem?: () => React.ReactElement; wrapperStyle({index}: {index: number}): React.CSSProperties;
}) {
  const {setNodeRef, setActivatorNodeRef, listeners, isDragging, isSorting, over, overIndex, transform, transition} = useSortable({id});
  const mounted = useMountStatus();
  const mountedWhileDragging = isDragging && !mounted;
  return (
    <DemoItem
      ref={disabled ? undefined : setNodeRef}
      value={id} dragging={isDragging} sorting={isSorting} handle={handle}
      handleProps={handle ? {ref: setActivatorNodeRef} : undefined}
      wrapperStyle={wrapperStyle({index})}
      style={style({
        index, value: id, isDragging, isSorting,
        overIndex: over ? getIndex(over.id) : overIndex, containerId,
      })}
      color={getColor(id)}
      transition={transition} transform={transform}
      fadeIn={mountedWhileDragging} listeners={listeners} renderItem={renderItem}
    />
  );
}

function useMountStatus() {
  const [isMounted, setIsMounted] = useState(false);
  useEffect(() => { const t = setTimeout(() => setIsMounted(true), 500); return () => clearTimeout(t); }, []);
  return isMounted;
}

function createRange<T = number>(length: number, mapFn?: (index: number) => any): T[] {
  return Array.from({length}, (_, i) => (mapFn ? mapFn(i) : i) as T);
}
function getColor(id: UniqueIdentifier) {
  switch (String(id)[0]) {
    case 'A': return '#7193f1';
    case 'B': return '#ffda6c';
    case 'C': return '#00bcd4';
    case 'D': return '#ef769f';
    default : return undefined;
  }
}

/** Main demo export */
export interface MultipleContainersProps {
  adjustScale?: boolean; cancelDrop?: CancelDrop; columns?: number; containerStyle?: React.CSSProperties;
  coordinateGetter?: KeyboardCoordinateGetter;
  getItemStyles?(args: {
    value: UniqueIdentifier; index: number; overIndex: number; isDragging: boolean;
    containerId: UniqueIdentifier; isSorting: boolean; isDragOverlay: boolean;
  }): React.CSSProperties;
  wrapperStyle?(args: {index: number}): React.CSSProperties;
  itemCount?: number; items?: Items; handle?: boolean; renderItem?: any;
  strategy?: SortingStrategy; modifiers?: Modifiers; minimal?: boolean;
  trashable?: boolean; scrollable?: boolean; vertical?: boolean;
}

export function MultipleContainersDemo({
  adjustScale = false, itemCount = 3, cancelDrop, columns, handle = false, items: initialItems,
  containerStyle, coordinateGetter = multipleContainersCoordinateGetter, getItemStyles = () => ({}),
  wrapperStyle = () => ({}), minimal = false, modifiers, renderItem, strategy = verticalListSortingStrategy,
  trashable = false, vertical = false, scrollable,
}: MultipleContainersProps) {
  const [items, setItems] = useState<Items>(() => initialItems ?? {
    A: createRange(itemCount, (i) => `A${i + 1}`),
    B: createRange(itemCount, (i) => `B${i + 1}`),
    C: createRange(itemCount, (i) => `C${i + 1}`),
    D: createRange(itemCount, (i) => `D${i + 1}`),
  });
  const [containers, setContainers] = useState(Object.keys(items) as UniqueIdentifier[]);
  const [activeId, setActiveId] = useState<UniqueIdentifier | null>(null);
  const lastOverId = useRef<UniqueIdentifier | null>(null);
  const recentlyMovedToNewContainer = useRef(false);
  const isSortingContainer = activeId != null ? containers.includes(activeId) : false;

  const collisionDetectionStrategy: CollisionDetection = useCallback((args) => {
    if (activeId && activeId in items) {
      return closestCenter({
        ...args,
        droppableContainers: args.droppableContainers.filter((c) => c.id in items),
      });
    }
    const pointerIntersections = pointerWithin(args);
    const intersections = pointerIntersections.length > 0 ? pointerIntersections : rectIntersection(args);
    let overId = getFirstCollision(intersections, 'id');
    if (overId != null) {
      if (overId === TRASH_ID) return intersections;
      if (overId in items) {
        const containerItems = items[overId];
        if (containerItems.length > 0) {
          overId = closestCenter({
            ...args,
            droppableContainers: args.droppableContainers.filter((container) =>
              container.id !== overId && containerItems.includes(container.id)
            ),
          })[0]?.id;
        }
      }
      lastOverId.current = overId;
      return [{id: overId!}];
    }
    if (recentlyMovedToNewContainer.current) {
      lastOverId.current = activeId;
    }
    return lastOverId.current ? [{id: lastOverId.current}] : [];
  }, [activeId, items]);

  const [clonedItems, setClonedItems] = useState<Items | null>(null);
  const sensors = useSensors(
    useSensor(MouseSensor),
    useSensor(TouchSensor),
    useSensor(KeyboardSensor, {coordinateGetter})
  );

  const findContainer = (id: UniqueIdentifier) => {
    if (id in items) return id;
    return Object.keys(items).find((key) => items[key].includes(id));
  };
  const getIndex = (id: UniqueIdentifier) => {
    const container = findContainer(id);
    if (!container) return -1;
    return items[container].indexOf(id);
  };
  const onDragCancel = () => {
    if (clonedItems) setItems(clonedItems);
    setActiveId(null);
    setClonedItems(null);
  };
  useEffect(() => {
    requestAnimationFrame(() => { recentlyMovedToNewContainer.current = false; });
  }, [items]);

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={collisionDetectionStrategy}
      measuring={{ droppable: { strategy: MeasuringStrategy.Always } }}
      onDragStart={({active}) => { setActiveId(active.id); setClonedItems(items); }}
      onDragOver={({active, over}) => {
        const overId = over?.id;
        if (overId == null || overId === TRASH_ID || active.id in items) return;
        const overContainer = findContainer(overId);
        const activeContainer = findContainer(active.id);
        if (!overContainer || !activeContainer) return;
        if (activeContainer !== overContainer) {
          setItems((items) => {
            const activeItems = items[activeContainer];
            const overItems = items[overContainer];
            const overIndex = overItems.indexOf(overId);
            const activeIndex = activeItems.indexOf(active.id);
            let newIndex: number;
            if (overId in items) {
              newIndex = overItems.length + 1;
            } else {
              const isBelowOverItem =
                over && active.rect.current.translated &&
                active.rect.current.translated.top > over.rect.top + over.rect.height;
              const modifier = isBelowOverItem ? 1 : 0;
              newIndex = overIndex >= 0 ? overIndex + modifier : overItems.length + 1;
            }
            recentlyMovedToNewContainer.current = true;
            return {
              ...items,
              [activeContainer]: items[activeContainer].filter((item) => item !== active.id),
              [overContainer]: [
                ...items[overContainer].slice(0, newIndex),
                items[activeContainer][activeIndex],
                ...items[overContainer].slice(newIndex, items[overContainer].length),
              ],
            } as Items;
          });
        }
      }}
      onDragEnd={({active, over}) => {
        if (active.id in items && over?.id) {
          setContainers((containers) => {
            const activeIndex = containers.indexOf(active.id);
            const overIndex = containers.indexOf(over.id);
            return arrayMove(containers, activeIndex, overIndex);
          });
        }
        const activeContainer = findContainer(active.id);
        if (!activeContainer) { setActiveId(null); return; }
        const overId = over?.id;
        if (overId == null) { setActiveId(null); return; }
        if (overId === TRASH_ID) {
          setItems((items) => ({ ...items, [activeContainer]: items[activeContainer].filter((id) => id !== activeId) }));
          setActiveId(null);
          return;
        }
        if (overId === PLACEHOLDER_ID) {
          const newContainerId = getNextContainerId();
          unstable_batchedUpdates(() => {
            setContainers((containers) => [...containers, newContainerId]);
            setItems((items) => ({
              ...items,
              [activeContainer]: items[activeContainer].filter((id) => id !== activeId),
              [newContainerId]: [active.id],
            }));
            setActiveId(null);
          });
          return;
        }
        const overContainer = findContainer(overId);
        if (overContainer) {
          const activeIndex = items[activeContainer].indexOf(active.id);
          const overIndex = items[overContainer].indexOf(overId);
          if (activeIndex !== overIndex) {
            setItems((items) => ({
              ...items,
              [overContainer]: arrayMove(items[overContainer], activeIndex, overIndex),
            }));
          }
        }
        setActiveId(null);
      }}
      cancelDrop={cancelDrop}
      onDragCancel={onDragCancel}
      modifiers={modifiers}
    >
      <div style={{display: 'inline-grid', boxSizing: 'border-box', padding: 20,
                   gridAutoFlow: vertical ? 'row' : 'column', gap: 12}}>
        <SortableContext items={[...containers, PLACEHOLDER_ID]}
          strategy={vertical ? verticalListSortingStrategy : horizontalListSortingStrategy}>
          {containers.map((containerId) => (
            <DroppableContainer
              key={containerId}
              id={containerId}
              label={`Column ${containerId}`}
              columns={columns}
              items={items[containerId]}
              scrollable={scrollable}
              style={containerStyle}
              onClick={undefined}
              unstyled={false}
            >
              <SortableContext items={items[containerId]} strategy={strategy}>
                {items[containerId].map((value, index) => (
                  <SortableItem
                    disabled={isSortingContainer}
                    key={value}
                    id={value}
                    index={index}
                    handle={handle}
                    style={getItemStyles}
                    wrapperStyle={wrapperStyle({index})}
                    renderItem={renderItem}
                    containerId={containerId}
                    getIndex={getIndex}
                  />
                ))}
              </SortableContext>
            </DroppableContainer>
          ))}
          <DroppableContainer id={PLACEHOLDER_ID} disabled={isSortingContainer} items={empty} onClick={handleAddColumn} placeholder>
            + Add column
          </DroppableContainer>
        </SortableContext>
      </div>

      {createPortal(
        <DragOverlay adjustScale={adjustScale} dropAnimation={dropAnimation}>
          {activeId
            ? containers.includes(activeId)
              ? renderContainerDragOverlay(activeId)
              : renderSortableItemDragOverlay(activeId)
            : null}
        </DragOverlay>,
        document.body
      )}

      {trashable && activeId && !containers.includes(activeId) ? (
        <Trash id={TRASH_ID} />
      ) : null}
    </DndContext>
  );

  function renderSortableItemDragOverlay(id: UniqueIdentifier) {
    return (
      <DemoItem
        value={id}
        handle={handle}
        style={getItemStyles({
          containerId: findContainer(id) as UniqueIdentifier,
          overIndex: -1,
          index: getIndex(id),
          value: id,
          isSorting: true,
          isDragging: true,
          isDragOverlay: true,
        })}
        color={getColor(id)}
        wrapperStyle={wrapperStyle({index: 0})}
        renderItem={renderItem}
      />
    );
  }
  function renderContainerDragOverlay(containerId: UniqueIdentifier) {
    return (
      <DemoContainer label={`Column ${containerId}`} columns={columns} style={{height: '100%'}}>
        {items[containerId].map((item, index) => (
          <DemoItem
            key={item}
            value={item}
            handle={handle}
            style={getItemStyles({
              containerId,
              overIndex: -1,
              index: getIndex(item),
              value: item,
              isDragging: false,
              isSorting: false,
              isDragOverlay: false,
            })}
            color={getColor(item)}
            wrapperStyle={wrapperStyle({index})}
            renderItem={renderItem}
          />
        ))}
      </DemoContainer>
    );
  }
  function handleAddColumn() {
    const newContainerId = getNextContainerId();
    unstable_batchedUpdates(() => {
      setContainers((containers) => [...containers, newContainerId]);
      setItems((items) => ({...items, [newContainerId]: []}));
    });
  }
  function getNextContainerId() {
    const containerIds = Object.keys(items);
    const lastContainerId = containerIds[containerIds.length - 1];
    return String.fromCharCode(lastContainerId.charCodeAt(0) + 1);
  }
}

const dropAnimation: DropAnimation = {
  sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: '0.5' } } }),
};

export const defaultGetItemStyles: MultipleContainersProps['getItemStyles'] = ({isDragOverlay}) => ({
  background: isDragOverlay ? 'white' : 'white',
});

// Example usage (uncomment in a page):
// export default function Page() {
//   return (
//     <div className="p-6"><MultipleContainersDemo handle scrollable trashable getItemStyles={defaultGetItemStyles} /></div>
//   );
// }
