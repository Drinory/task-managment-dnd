# M1 — Routers & CRUD (tRPC + Zod)

**Implementation reference:** `/docs/ref/dnd/MultipleContainers.demo.tsx`

## 1) Routers Overview
- **TasksRouter**
  - `listByColumn({ columnId }) -> Task[]`
  - `move({ taskId, toColumnId, toIndex }) -> Task`
  - `remove({ taskId }) -> { ok: true }`
  - `create/update` as already defined
- **ColumnsRouter**
  - `listByProject({ projectId }) -> Column[]`
  - `create({ projectId, name }) -> Column`
  - `update({ id, name }) -> Column`
  - `remove({ id }) -> { ok: true }` (only allowed when empty)
  - **`move({ projectId, columnId, toIndex }) -> Column`**

## 2) ColumnsRouter.move
**Input**
```ts
z.object({
  projectId: z.string(),
  columnId : z.string(),
  toIndex  : z.number().int().min(0),
})
```
**Behavior**
- Load sibling columns by `projectId`, sorted by `order ASC`.
- Compute sparse **Int** `order` (see Ordering spec section):
  - start: `floor(next.order/2)` (renorm first if `next.order <= 1`)
  - between: `floor((prev.order + next.order)/2)`
  - end: `prev.order + 1000`
- If min gap `< 2` **or** after 50 column moves → **renormalize** (single transaction).
- **Idempotent**: if resulting index equals current, return success without changes.

**Errors**
- `BAD_REQUEST` invalid index
- `NOT_FOUND` project/column missing
- `CONFLICT` concurrent changes / constraint races
- `INTERNAL_SERVER_ERROR` fallback

## 3) Deletion Rules
- Project: disallow delete if it has columns (no cascade in MVP).
- Column : disallow delete if it has tasks.
- Task   : delete allowed.
- **Trash dropzone deletes tasks only**; columns are not deletable via drag.

