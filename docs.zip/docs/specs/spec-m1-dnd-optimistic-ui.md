# M1 — DnD Wiring & Optimistic UI (Aligned with dnd-kit “Multiple Containers”)

**Implementation reference:** `/docs/ref/dnd/MultipleContainers.demo.tsx`

## 1) Objective & Scope
Implement drag‑and‑drop for **tasks** (vertical within a column) and **columns** (horizontal across the board) using **dnd‑kit** with an **optimistic UI** flow (client cache reorder → tRPC mutate → settle/rollback).

### In‑scope
- **Sensors:** `MouseSensor`, `TouchSensor`, and `KeyboardSensor` with a custom `coordinateGetter` (keyboard DnD is supported). Pointer activation: `{ distance: 6 }`.
- **Collision:** Container‑first strategy: `pointerWithin` → fallback `rectIntersection` → **closestCenter inside the matched container**, with a `lastOverId` fallback to prevent jitter after layout shifts.
- **Measuring:** `measuring.droppable.strategy = MeasuringStrategy.Always`.
- **Overlay:** `DragOverlay` rendered via `createPortal`.
- **Sortable contexts:** top‑level **horizontal** `SortableContext` for columns; nested **vertical** `SortableContext` per column for tasks.
- **Empty‑column sentinel:** dropping into an empty column yields `toIndex = 0`.
- **“+ Add column” placeholder:** clicking (or dropping) triggers `columns.create`; server creates the ID.
- **Trash dropzone (optional flag):** available only when dragging **tasks**; drop → `tasks.remove`. **Columns are not deleted via trash.**
- **Optimistic update:** tasks → `tasks.move`; columns → `columns.move`.

### Out‑of‑scope
- Virtualization (defer; enable behind a threshold later).

## 2) Traceability
- **SAD v1:** dnd‑kit, multi‑sensor, container‑first collision, Always measuring, DragOverlay, optimistic UI, sparse `order` for tasks & columns, renormalization.

## 3) Wiring (sketch)
```tsx
<DndContext
  sensors={useSensors(
    useSensor(MouseSensor),
    useSensor(TouchSensor),
    useSensor(KeyboardSensor, { coordinateGetter })
  )}
  collisionDetection={collisionDetectionStrategy}
  measuring={{ droppable: { strategy: MeasuringStrategy.Always } }}
  onDragStart={setActive}
  onDragOver={maybeCrossColumnOptimistic}
  onDragEnd={commitMove /* tasks.move or columns.move */}
>
  <SortableContext items={[...columnIds, PLACEHOLDER_ID]} strategy={horizontalListSortingStrategy}>
    {columnIds.map(cid => (
      <DroppableContainer key={cid} id={cid} items={tasksByColumn[cid]}>
        <SortableContext items={tasksByColumn[cid]} strategy={verticalListSortingStrategy}>
          {/* task items */}
        </SortableContext>
      </DroppableContainer>
    ))}
    <DroppableContainer id={PLACEHOLDER_ID} items={[]} onClick={createColumn} placeholder>
      + Add column
    </DroppableContainer>
  </SortableContext>
  <DragOverlay>{activeId && renderOverlay(activeId)}</DragOverlay>
</DndContext>
```

**CollisionDetection:** use the Multiple‑Containers container‑first approach with `lastOverId` fallback.

## 4) Optimistic Contract
1. **Task drop**: derive `(toColumnId, toIndex)` → optimistic reorder in cache → call `tasks.move` → **success**: invalidate from/to columns → **error**: rollback + toast.
2. **Column drop**: derive `toIndex` → optimistic reorder of columns cache → call `columns.move` → settle as above.
3. **Trash drop (task)**: optimistic hide → call `tasks.remove` → settle/rollback.

## 5) Rules & Edge Cases
- Drop outside any column → cancel (no mutation).
- Same column & same index → no‑op.
- Empty column shows full‑height sentinel; drop → `toIndex=0`.
- Trash visible only while dragging **tasks**. Columns must be deleted explicitly when **empty** (not via trash).

## 6) Errors & Idempotency
- Error codes: `BAD_REQUEST`, `NOT_FOUND`, `CONFLICT`, `INTERNAL_SERVER_ERROR`.
- Do not auto‑retry optimistic updates; user can re‑drag.
- Idempotency: moving to the same final index is a no‑op success on server.

## 7) QA Acceptance
- Mouse, touch, and keyboard DnD all work.
- Columns can be reordered horizontally; tasks vertically.
- Add‑column placeholder creates a server column and uses its returned ID in UI.
- Trash deletes tasks only.
- Measured layout updates are stable (no jitter when moving between containers).

