# M1 — Task Move & Ordering + Column Move & Ordering

**Implementation reference:** `/docs/ref/dnd/MultipleContainers.demo.tsx`

## 1) Models (relevant fields)
```ts
type Column = { id: string; projectId: string; name: string; order: number; createdAt: Date }
type Task   = { id: string; columnId : string; title: string; order: number; createdAt: Date }
```

## 2) Shared Principles
- Use **sparse Int `order`** with initial step `1000`.
- Sort ascending by `order` within the parent scope (project → columns, column → tasks).
- Compute `newOrder` from immediate neighbors; renormalize when gaps vanish.

## 3) Task Move (recap)
**Semantics**
- Start:     `newOrder = floor(next.order / 2)` (renorm if `<= 1`)
- Between:   `newOrder = floor((prev.order + next.order) / 2)`
- End:       `newOrder = prev.order + 1000`
- Cross‑column: neighbors are taken from the **destination** column list.
- Atomic, single transaction.
- Idempotency: moving to same index is a no‑op.
- Errors: `BAD_REQUEST`, `NOT_FOUND`, `CONFLICT`, `INTERNAL_SERVER_ERROR`.

**tRPC**: `TasksRouter.move({ taskId, toColumnId, toIndex }) -> Task`

## 4) Column Move (NEW)
**Scope**: siblings are **columns** in the same project.

**Semantics**
- Start:     `newOrder = floor(next.order / 2)` (renorm first if `<= 1`)
- Between:   `newOrder = floor((prev.order + next.order) / 2)`
- End:       `newOrder = prev.order + 1000`
- Atomic transaction; updates only the project’s columns.
- Idempotency: if final index unchanged, return success.

**Renormalization**
- When min gap `< 2` **or** after **50** column moves (whichever first).
- Reassign orders to `1000, 2000, 3000, …` for the scope.
- Performed atomically along with the triggering move when needed.

**tRPC**: `ColumnsRouter.move({ projectId, columnId, toIndex }) -> Column`

## 5) Tests
- Property: after N random moves (tasks and columns), orders remain strictly increasing within scope.
- Contract: Zod rejects invalid indices; correct error codes returned.
- Integration: UI drag operations persist server order; repeated same move is a no‑op success.

