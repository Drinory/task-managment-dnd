# M1 — Seed / Reset / DX Smoke

**Implementation reference:** `/docs/ref/dnd/MultipleContainers.demo.tsx`

## 1) Seed
- Create demo project(s) with columns seeded at `order = 1000, 2000, …`.
- Create tasks seeded similarly per column (`order = 1000, 2000, …`).
- Indexes:
  - `Column(projectId, order)`
  - `Task(columnId, order)`

## 2) Reset
- `pnpm db:reset` (or equivalent) drops + migrates + seeds deterministically.

## 3) Smoke Script (E2E‑lite)
**Steps**
1. Create a project (or use seeded one).
2. Move **10 random tasks** across columns (including within‑column).
3. Move **3 random columns** to random indices within the project.
4. Validate invariants:
   - For every column: `Task.order` strictly increasing.
   - For every project: `Column.order` strictly increasing.
5. Print a tiny timing + counts report; exit 0.

**Invariants**
- After seed: each column and task list is `1000,2000, …`.
- After moves: orders remain strictly increasing in both dimensions.

